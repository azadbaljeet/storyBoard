//
//  SecondViewController.h
//  SideMenu
//
//  Created by Yogesh Singh Rana on 13/12/15.
//  Copyright (c) 2015 Yogesh Singh Rana. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *secWebView;

@end
